
A test application to play with django-ajax-selects


INSTALL ±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±

Install a local django in a virtualenv:

./install.sh

This will also activate the virtualenv and create a sqlite db


Run the server:

./manage.py runserver

Go visit the admin site and play around:

http://127.0.0.1:8000/admin


DEACTIVATE ±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±

To deactiveate the virtualenv just close the shell or:

deactivate


REACTIVATE ±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±±

Reactivate it later:

source AJAXSELECTS/bin/activate

